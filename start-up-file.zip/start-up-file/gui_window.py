import tkinter as tk
import subprocess

def run_uvicorn():
    command = r'cd C:\Users\PMLS\Downloads\ch-tbot_aa-main\ && .\myenv\Scripts\Activate && uvicorn main:app --reload'
    subprocess.Popen(['cmd.exe', '/C', 'start', 'cmd.exe', '/K', command], shell=True)

def run_streamlit():
    command = r'cd C:\Users\PMLS\Downloads\ch-tbot_aa-main\ && .\myenv\Scripts\Activate && streamlit run app.py'
    subprocess.Popen(['cmd.exe', '/C', 'start', 'cmd.exe', '/K', command], shell=True)

# Creating the GUI
root = tk.Tk()
root.title("Auto Assist Chatbot")
root.configure(background='black')
root.geometry("500x300")  # Setting window size

# Function to create styled buttons
def create_styled_button(parent, text, command):
    button = tk.Button(parent, text=text, command=command, bg="gray", fg="white", relief=tk.RAISED, bd=0, padx=20, pady=10, font=('Arial', 14, 'bold'), width=15)
    
    # Adding hover effect
    def on_enter(e):
        button['bg'] = 'white'
        button['fg'] = 'gray'

    def on_leave(e):
        button['bg'] = 'gray'
        button['fg'] = 'white'

    button.bind("<Enter>", on_enter)
    button.bind("<Leave>", on_leave)
    
    return button

# Logo (optional)
# Replace logo_url with your actual logo URL
logo_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRW9NWd7e-wySL6H4R0nBC6QjirbzVNgkr4Sw&usqp=CAU"

# Layout
logo_label = tk.Label(root, text="Auto Assist Chatbot", font=('Arial', 20, 'bold'), fg="#FF4500", bg="black")
logo_label.pack(pady=20)

uvicorn_button = create_styled_button(root, "Run Uvicorn", run_uvicorn)
uvicorn_button.pack(pady=10)

streamlit_button = create_styled_button(root, "Run Streamlit", run_streamlit)
streamlit_button.pack(pady=10)

# Start the GUI
root.mainloop()
