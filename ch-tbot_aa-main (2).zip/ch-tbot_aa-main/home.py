import streamlit as st
import requests

def show_home_page():
    # Inject custom CSS for buttons to match the title gradient color and increase width
    st.markdown(
        """
        <style>
        .stButton>button {
            color: #FFFFFF;  /* White text color */
            background-image: linear-gradient(to right, #FF1493, #FF4500);  /* Gradient color */
            border: none;
            border-radius: 20px; /* Rounded corners for the button */
            padding: 12px 30px; /* Adjust padding to increase button width */
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            transition-duration: 0.4s;
            cursor: pointer;
            min-width: 150px; /* Ensure minimum width for the button */
        }
        .stSidebar .stButton>button {
            background-image: linear-gradient(to right, #FF1493, #FF4500);  /* Gradient color */
            border-radius: 20px; /* Rounded corners for the button */
            padding: 12px 30px; /* Adjust padding to increase button width */
            min-width: 150px; /* Ensure minimum width for the button */
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # FastAPI endpoint URLs
    #BASE_URL = "http://127.0.0.1:8000"
    BASE_URL = "http://127.0.0.1:8000"
    CREATE_CHAT_URL = f"{BASE_URL}/create_chat/"
    QUERY_CHAT_URL = f"{BASE_URL}/query/"
    DELETE_CHAT_URL = f"{BASE_URL}/chats/"
    LIST_CHATS_URL = f"{BASE_URL}/chats/"
    

    # Function to list all chats
    def list_chats():
        response = requests.get(LIST_CHATS_URL)
        if response.status_code == 200:
            return response.json().get("chat_ids", [])
        else:
            st.sidebar.error("Error retrieving chat list.")
            return []

    # Sidebar buttons
    if st.sidebar.button("New Chat", help="Start a new chat conversation"):
        response = requests.post(CREATE_CHAT_URL)
        if response.status_code == 200:
            chat_id = response.json()["chat_id"]
            st.session_state.chat_id = chat_id
            st.session_state.chat_history = []
        else:
            st.sidebar.error("Error creating a new chat.")

    if st.sidebar.button("Delete Chat", help="Delete current chat conversation"):
        if 'chat_id' in st.session_state:
            response = requests.delete(f"{DELETE_CHAT_URL}{st.session_state.chat_id}/")
            if response.status_code == 200:
                st.sidebar.success("Chat deleted successfully.")
                st.session_state.chat_id = None
                st.session_state.chat_history = []
            else:
                st.sidebar.error("Error deleting the chat.")
        else:
            st.sidebar.warning("No chat to delete.")

    # List previous chats in sidebar
    chat_ids = list_chats()
    if chat_ids:
        st.sidebar.markdown("### Previous Chats")
        chat_options = [f"Chat {i + 1}" for i in range(len(chat_ids))]
        chat_id_to_display_name = dict(zip(chat_ids, chat_options))
        display_name_to_chat_id = {v: k for k, v in chat_id_to_display_name.items()}

        selected_chat_display_name = st.sidebar.selectbox("Select a chat to continue", chat_options)
        selected_chat_id = display_name_to_chat_id[selected_chat_display_name]

        if st.sidebar.button("Load Chat"):
            response = requests.get(f"{LIST_CHATS_URL}{selected_chat_id}/")
            if response.status_code == 200:
                st.session_state.chat_id = selected_chat_id
                st.session_state.chat_history = response.json().get("chat_history", [])
            else:
                st.sidebar.error("Error loading the chat history.")

    # Sidebar content
    st.sidebar.markdown(
        """
        <div style="color: #FFFFFF; background-image: linear-gradient(to right, #FF1493 , #FF4500); padding: 10px; border-radius: 20px; font-size: 14px; text-align: center;">
            <p style="margin:0;">Call Now</p>
            <p style="margin:0; font-weight: bold;">0330 010 0411</p>
        </div>
        <br>
        <div style="text-align: justify;">
            <h2>Auto Assist Mission</h2>
            <p>Our mission is to provide comprehensive and cost-effective fleet maintenance solutions that help businesses optimise their fleet's performance while reducing costs and minimising downtime. We believe that our client's success is our success, which is why we focus on building long-lasting relationships with our clients based on trust, honesty, and mutual respect.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    # User input
    user_query = st.text_area("Your Query", "", height=100)

    if st.button("Send"):
        if 'chat_id' not in st.session_state:
            st.error("Please start a new chat first.")
        else:
            response = requests.post(f"{QUERY_CHAT_URL}{st.session_state.chat_id}/", json={"user_query": user_query})
            if response.status_code == 200:
                answer = response.json()['response']
                st.session_state.chat_history.append((user_query, answer))
            else:
                st.error("Error from the chatbot API.")

    # Display chat history
    if 'chat_history' in st.session_state:
        for query, response in st.session_state.chat_history:
            st.markdown(f"**You:** {query}", unsafe_allow_html=True)
            st.markdown(f"**Auto Assist Bot:** {response}", unsafe_allow_html=True)
            st.markdown("---", unsafe_allow_html=True)
