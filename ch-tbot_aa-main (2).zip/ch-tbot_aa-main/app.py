import streamlit as st
import os
import sqlite3
from home import show_home_page
from auth import signup, login

def main():
    st.set_page_config(page_title="Auto Assist Chatbot", layout="wide")

    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False

    logo_url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRW9NWd7e-wySL6H4R0nBC6QjirbzVNgkr4Sw&usqp=CAU"
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;">
            <img src="{logo_url}" alt="Auto Assist Chatbot Logo" style="width:80px;height:80px;">
            <h1 style="margin-left:10px;color:#FF4500;">Auto Assist Chatbot</h1>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown(
        """
        <style>
        .stButton>button {
            color: #FFFFFF;
            background-image: linear-gradient(to right, #FF1493, #FF4500);
            border: none;
            border-radius: 20px;
            padding: 12px 30px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            transition-duration: 0.4s;
            cursor: pointer;
            min-width: 150px;
        }
        .stSidebar .stButton>button {
            background-image: linear-gradient(to right, #FF1493, #FF4500);
            border-radius: 20px;
            padding: 12px 30px;
            min-width: 150px;
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    # Function to create a connection to the SQLite database
    def create_connection():
        # db_path = os.path.join(os.path.dirname(__file__), 'C:\Users\PMLS\Downloads\ch-tbot_aa-main\database.db')
        db_path = os.path.join(os.path.dirname(__file__), 'C:\\Users\\PMLS\\Downloads\\ch-tbot_aa-main\\database.db')

        conn = sqlite3.connect(db_path)
        return conn

    def is_valid_input(username, password):
        prefix = "autoassist"
        return username.startswith(prefix) and password.startswith(prefix)

    if st.session_state.logged_in:
        if st.sidebar.button('Back to Login'):
            st.session_state.logged_in = False
            st.experimental_rerun()
        show_home_page()
    else:
        choice = st.radio("Choose an option:", ('Signup', 'Login'))

        if choice == 'Signup':
            st.markdown('### Signup')
            username_signup = st.text_input('Username (Signup)', key='username_signup')
            password_signup = st.text_input('Password (Signup)', type='password', key='password_signup')
            confirm_password_signup = st.text_input('Confirm Password (Signup)', type='password', key='confirm_password_signup')

            if st.button('Signup'):
                if password_signup == confirm_password_signup:
                    if is_valid_input(username_signup, password_signup):
                        signup(username_signup, password_signup)
                        st.success('Signup successful!')
                    else:
                        st.error('You are not able to use "autoassist chatbot".')
                else:
                    st.error('Passwords do not match.')

        elif choice == 'Login':
            st.markdown('### Login')
            username_login = st.text_input('Username (Login)', key='username_login')
            password_login = st.text_input('Password (Login)', type='password', key='password_login')

            if st.button('Login'):
                if is_valid_input(username_login, password_login):
                    if login(username_login, password_login):
                        st.session_state.logged_in = True
                        st.experimental_rerun()
                    else:
                        st.error('Incorrect username or password.')
                else:
                    st.error('You are not able to use "autoassist chatbot".')

if __name__ == '__main__':
    main()
